<?php
session_start();
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');

if (!isset($_SESSION['userID']) || ($_SESSION['role'] != 'Admin' && $_SESSION['role'] != 'Teacher')) {
    header("Location: /RWDD/General/login.php");
    exit();
}

// Retrieve questionID from either GET or POST
$questionID = isset($_POST['questionID']) ? $_POST['questionID'] : (isset($_GET['questionID']) ? $_GET['questionID'] : null);

if (!$questionID) {
    echo "<script>alert('Missing required data!'); window.history.back();</script>";
    exit();
}

// Retrieve quizID and quizName
$stmt = $dbConn->prepare("SELECT quizID FROM question WHERE questionID = ?");
$stmt->bind_param("i", $questionID);
$stmt->execute();
$stmt->bind_result($quizID);
$stmt->fetch();
$stmt->close();

$stmt = $dbConn->prepare("SELECT quizTitle FROM quiz WHERE quizID = ?");
$stmt->bind_param("i", $quizID);
$stmt->execute();
$stmt->bind_result($quizName);
$stmt->fetch();
$stmt->close();


// // Delete options first
// $deleteOptionsStmt = $dbConn->prepare("DELETE FROM Options WHERE questionID = ?");
// $deleteOptionsStmt->bind_param("i", $questionID);
// $deleteOptionsStmt->execute();
// $deleteOptionsStmt->close();

// // Delete question
// $deleteQuestionStmt = $dbConn->prepare("DELETE FROM Question WHERE questionID = ?");
// $deleteQuestionStmt->bind_param("i", $questionID);
// $deleteQuestionStmt->execute();
// $deleteQuestionStmt->close();

// Check remaining questions in quiz
$stmt = $dbConn->prepare("SELECT COUNT(*) FROM Question WHERE quizID = ?");
$stmt->bind_param("i", $quizID);
$stmt->execute();
$stmt->bind_result($questionCount);
$stmt->fetch();
$stmt->close();

if ($questionCount  <=1) {
    // if ($_SESSION['role'] != 'Admin') {
        // Redirect to teacherCreateQuiz2.php with a message that at least one question is needed
        echo "<script>
        alert('You must have at least one question to complete the quiz!');
        window.history.back();
        </script>";

        // alert('Question deleted successfully! You must have at least one question to complete the quiz.');
        // echo "<script>alert('Quiz deleted successfully!'); window.location.href='/RWDD/admin&teacher/adminPage.php';</script>";
    // }else{
    //     echo "<script>
    //     alert('You must have at least one question to complete the quiz.');
    // </script>";
    // }
    // Redirect to teacherCreateQuiz2.php with a message that at least one question is needed
    // echo "<script>
    //     alert('Question deleted successfully! You must have at least one question to complete the quiz.');
    //     window.location.href='/RWDD/admin&teacher/teacherCreateQuiz2.php?quizID=$quizID&quizName=" . urlencode($quizName) . "';
    // </script>";
} else {
    // Delete options first
    $deleteOptionsStmt = $dbConn->prepare("DELETE FROM Options WHERE questionID = ?");
    $deleteOptionsStmt->bind_param("i", $questionID);
    $deleteOptionsStmt->execute();
    $deleteOptionsStmt->close();

    // Delete question
    $deleteQuestionStmt = $dbConn->prepare("DELETE FROM Question WHERE questionID = ?");
    $deleteQuestionStmt->bind_param("i", $questionID);
    $deleteQuestionStmt->execute();
    $deleteQuestionStmt->close();

    if ($_SESSION['role'] != 'Admin') {
        echo "<script>
            alert('Question deleted successfully!');
            window.location.href='/RWDD/admin&teacher/teacherCreateQuiz2.php?quizID=$quizID&quizName=" . urlencode($quizName) . "';
        </script>";
    } else {
        echo "<script>
            alert('Question deleted successfully!');
            window.history.back();
        </script>";
    }
    // echo "<script>
    //     alert('Question deleted successfully!');
    //     window.location.href='/RWDD/admin&teacher/teacherCreateQuiz2.php?quizID=$quizID&quizName=" . urlencode($quizName) . "';
    // </script>";
}
?>

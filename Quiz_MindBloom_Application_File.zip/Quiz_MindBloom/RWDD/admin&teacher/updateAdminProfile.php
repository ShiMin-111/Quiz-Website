<?php
// Start the session
session_start();

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');  // Ensure correct path

// Check if the user is logged in
if (!isset($_SESSION['userID']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

$userID = $_SESSION['userID'];
$newusername = $_POST['username'];

// Initialize variables for profile picture update
$updateProfilePicture = false;
$imageData = null;

if (isset($_FILES['profile-pic']) && $_FILES['profile-pic']['error'] == 0) {
    $imageTmpName = $_FILES['profile-pic']['tmp_name'];
    $imageSize = $_FILES['profile-pic']['size'];
    $imageType = $_FILES['profile-pic']['type'];

    // Validate file type and size
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (in_array($imageType, $allowedTypes) && $imageSize <= 5000000) { // 5MB limit
        $imageData = file_get_contents($imageTmpName);
        $updateProfilePicture = true;
    } else {
        $_SESSION['errorMessage'] = "Invalid file type or size. Please upload a valid image.";
        header("Location: teacherEditProfile.php");
        exit();
    }
}

// Prepare the SQL query based on whether a profile picture is being updated
if ($updateProfilePicture) {
    $updateStmt = $dbConn->prepare("UPDATE Users SET username = ?, profilePicture = ? WHERE userID = ?");
    $updateStmt->bind_param("ssi", $newusername, $imageData, $userID);
    $updateStmt->send_long_data(1, $imageData);  // ✅ Send the blob data
}else{
// Update only username and subjectTaught
$updateStmt = $dbConn->prepare("UPDATE Users SET username = ? WHERE userID = ?");
$updateStmt->bind_param("si", $newusername, $userID);
}

if ($updateStmt->execute()) {
    $_SESSION['successMessage'] = "Profile updated successfully!";
} else {
    $_SESSION['errorMessage'] = "Failed to update profile. Please try again.";
}
$updateStmt->close();
// Redirect back to the profile edit page
header("Location: adminEditProfile.php");
exit();        
?>

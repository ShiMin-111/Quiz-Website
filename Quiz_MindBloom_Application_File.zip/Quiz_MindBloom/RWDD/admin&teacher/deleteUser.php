<?php
// Start the session
session_start();

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');  //absolute path (you must enter specific path)

// Check if the user is logged in and has the role of 'Admin'
if (!isset($_SESSION['userID']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Check if the request is a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the userID from the POST request
    $userID = $_POST['userID'];

    // Update the approval status to 'Deleted'
    $stmt = $dbConn->prepare("UPDATE Users SET approvalStatus = 'Deleted' WHERE userID = ?");
    $stmt->bind_param("i", $userID);

    if ($stmt->execute()) {
        echo "User account deleted successfully.";
    } else {
        echo "Failed to delete user account.";
    }

    $stmt->close();
}
?>
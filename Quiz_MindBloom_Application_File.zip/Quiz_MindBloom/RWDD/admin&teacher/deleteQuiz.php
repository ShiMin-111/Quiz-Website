<?php
// Start the session
session_start();

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');

// Check if the user is logged in and has the role of 'Admin' or 'Teacher'
if (!isset($_SESSION['userID']) || ($_SESSION['role'] != 'Admin' && $_SESSION['role'] != 'Teacher')) {
    header("Location: /RWDD/General/login.php");
    exit();
}

// Retrieve the quiz ID from the URL
if (!isset($_GET['quizID'])) {
    echo "<script>alert('Quiz ID is missing!'); window.history.back();</script>";
    exit();
}
$quizID = $_GET['quizID'];

// Retrieve the quiz details to check the creator
$quizStmt = $dbConn->prepare("SELECT createdBy FROM Quiz WHERE quizID = ?");
$quizStmt->bind_param("i", $quizID);
$quizStmt->execute();
$quizStmt->bind_result($createdBy);
$quizStmt->fetch();
$quizStmt->close();

// Check if the user is an Admin or the creator of the quiz
if ($_SESSION['role'] == 'Admin' || ($_SESSION['role'] == 'Teacher' && $_SESSION['userID'] == $createdBy)) {

    // Step 1: Retrieve all question IDs
    $questionIDs = [];
    $questionStmt = $dbConn->prepare("SELECT questionID FROM Question WHERE quizID = ?");
    $questionStmt->bind_param("i", $quizID);
    $questionStmt->execute();
    $questionStmt->bind_result($questionID);
    
    while ($questionStmt->fetch()) {
        $questionIDs[] = $questionID;
    }
    $questionStmt->close();

    // Step 2: Delete options for each question
    if (!empty($questionIDs)) {
        $deleteOptionsStmt = $dbConn->prepare("DELETE FROM Options WHERE questionID = ?");
        foreach ($questionIDs as $qID) {
            $deleteOptionsStmt->bind_param("i", $qID);
            $deleteOptionsStmt->execute();
        }
        $deleteOptionsStmt->close();
    }

    // Step 3: Delete all questions related to the quiz
    $deleteQuestionsStmt = $dbConn->prepare("DELETE FROM Question WHERE quizID = ?");
    $deleteQuestionsStmt->bind_param("i", $quizID);
    $deleteQuestionsStmt->execute();
    $deleteQuestionsStmt->close();

    // Step 4: Delete all submissions related to the quiz
    $deleteSubmissionsStmt = $dbConn->prepare("DELETE FROM Submission WHERE quizID = ?");
    $deleteSubmissionsStmt->bind_param("i", $quizID);
    $deleteSubmissionsStmt->execute();
    $deleteSubmissionsStmt->close();

    // Step 5: Delete the quiz
    $deleteQuizStmt = $dbConn->prepare("DELETE FROM Quiz WHERE quizID = ?");
    $deleteQuizStmt->bind_param("i", $quizID);
    $deleteQuizStmt->execute();
    $deleteQuizStmt->close();

    // Redirect based on user role
    if ($_SESSION['role'] == 'Admin') {
        $redirectUrl = '/RWDD/admin&teacher/adminPage.php';
    } else {
        $redirectUrl = '/RWDD/admin&teacher/teacherPage.php';
    }

    echo "<script>alert('Quiz deleted successfully!'); window.location.href='$redirectUrl';</script>";
} else {
    echo "<script>alert('You do not have permission to delete this quiz.'); window.history.back();</script>";
}
?>
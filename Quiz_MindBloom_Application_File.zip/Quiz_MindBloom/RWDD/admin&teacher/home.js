// Carousel Functionality
let currentImageIndex = 0; // Start with the first image (index 0)
const images = document.querySelectorAll('.carousel-image'); // Select all carousel images

function switchImage(direction) {
    // Remove 'active' class from the current image
    images[currentImageIndex].classList.remove('active');

    // Update the index
    currentImageIndex += direction;

    // Loop back to the first/last image if out of bounds
    if (currentImageIndex < 0) {
        currentImageIndex = images.length - 1; // Go to the last image
    } else if (currentImageIndex >= images.length) {
        currentImageIndex = 0; // Go to the first image
    }

    // Add 'active' class to the new image
    images[currentImageIndex].classList.add('active');
}

// Automatically set the first image as active when the page loads
window.onload = () => {
    images[currentImageIndex].classList.add('active');

    // Add event listeners to carousel buttons
    document.querySelector('.prev').addEventListener('click', () => switchImage(-1));
    document.querySelector('.next').addEventListener('click', () => switchImage(1));
};


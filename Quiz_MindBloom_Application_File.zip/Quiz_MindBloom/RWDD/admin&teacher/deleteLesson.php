<?php
// deleteLesson.php
session_start();
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');

// Retrieve the lesson ID from the URL
if (!isset($_GET['lessonID'])) {
    echo "<script>alert('Lesson ID is missing!'); window.history.back();</script>";
    exit();
}
$lessonID = $_GET['lessonID'];

// Retrieve the lesson details to check the creator
$lessonStmt = $dbConn->prepare("SELECT userID FROM lesson WHERE lessonID = ?");
$lessonStmt->bind_param("i", $lessonID);
$lessonStmt->execute();
$lessonStmt->bind_result($userID);
$lessonStmt->fetch();
$lessonStmt->close();

// Check if the user is an Admin or the creator of the lesson
if ($_SESSION['role'] == 'Admin' || ($_SESSION['role'] == 'Teacher' && $_SESSION['userID'] == $userID)) {
    
    // Delete flashcards related to the lesson
    $deleteFlashcardStmt = $dbConn->prepare("DELETE FROM flashcard WHERE lessonID = ?");
    $deleteFlashcardStmt->bind_param("i", $lessonID);
    $deleteFlashcardStmt->execute();
    $deleteFlashcardStmt->close();

    // Delete the lesson
    $deleteLessonStmt = $dbConn->prepare("DELETE FROM lesson WHERE lessonID = ?");
    $deleteLessonStmt->bind_param("i", $lessonID);
    $deleteLessonStmt->execute();
    $deleteLessonStmt->close();
    
    if ($_SESSION['role'] != 'Admin') {
        echo "<script>alert('Lesson deleted successfully!'); window.location.href='/RWDD/admin&teacher/teacherCreation.php';</script>";
    }else{
        echo "<script>alert('Lesson deleted successfully!'); window.location.href='/RWDD/admin&teacher/adminPage.php';</script>";
    }

} else {
    echo "<script>alert('You do not have permission to delete this lesson.'); window.history.back();</script>";
}
?>

<?php
session_start();
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');

// Check if the user is an admin
if (!isset($_SESSION['userID']) || $_SESSION['role'] != 'Admin') {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit();
}

// Check if userID and status are provided
if (isset($_POST['userID']) && isset($_POST['status'])) {
    $userID = $_POST['userID'];
    $status = $_POST['status'];

    // Ensure status is either 'Approved' or 'Rejected'
    if ($status !== 'Approved' && $status !== 'Rejected') {
        echo json_encode(["status" => "error", "message" => "Invalid status"]);
        exit();
    }

    // Prepare and execute the SQL update
    $stmt = $dbConn->prepare("UPDATE Users SET approvalStatus = ? WHERE userID = ?");
    $stmt->bind_param("si", $status, $userID);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "User approval status updated"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update status"]);
    }

    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
}
?>

<?php
// Start the session
session_start();

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');  //absolute path (you must enter specific path)


// Retrieve the admin's profile data
$adminuserID = $_SESSION['userID'];
$adminstmt = $dbConn->prepare("SELECT username, email, profilePicture FROM Users WHERE userID = ?");
$adminstmt->bind_param("i", $adminuserID);
$adminstmt->execute();
$adminstmt->bind_result($username, $email, $adminprofilePicture);
$adminstmt->fetch();
$adminstmt->close();

// Check if the user is logged in and has the role of 'Admin'
if (!isset($_SESSION['userID']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Retrieve the user ID from the query string
$userID = isset($_GET['userID']) ? intval($_GET['userID']) : 0;

// Fetch the user details from the database
$stmt = $dbConn->prepare("SELECT username, email, profilePicture, role, subjectTaught, grade FROM Users WHERE userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$stmt->bind_result($username, $email, $profilePicture, $role, $subjectTaught, $grade);
$stmt->fetch();
$stmt->close();

// Check if the profile picture is empty or NULL
if (!empty($adminprofilePicture)) {
  // Convert BLOB to base64 format
  $profilePic = 'data:image/jpeg;base64,' . base64_encode($adminprofilePicture);
} else {
  $profilePic = "/RWDD/Image/admin.png"; // Default avatar
}

// Check if the profile picture is empty or NULL
if (!empty($profilePicture)) {
  // Convert BLOB to base64 format
  $profilePicture = 'data:image/jpeg;base64,' . base64_encode($profilePicture);
} else {
  if ($role == 'Teacher'){
    $profilePicture = "/RWDD/Image/teacher.png"; // Default avatar
  }elseif($role == 'Student'){
    $profilePicture = "/RWDD/Image/student.png"; // Default avatar
  }elseif($role == 'Admin'){
    $profilePicture = "/RWDD/Image/admin.png"; // Default avatar
  }
  
   
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MindBloom Admin - View Account Details</title>
    <link rel="stylesheet" href="/RWDD/admin&teacher/home.css"> 
    <link rel="stylesheet" href="admin.css"> 
    <link rel="stylesheet" href="/RWDD/Student/burger.css">
</head>
<body>
    <header>
        <div class="header-logo">
          <div class="header-logo-circle">
            <img src="/RWDD/Image/Tree Icon.png" alt="MindBloom Logo" class="header-logo-img">
          </div>
          <span class="brand-name-header">MindBloom</span>
        </div>
      
        <div class="welcome">
          <p>Welcome back, <span><?php echo htmlspecialchars($_SESSION['username']); ?></span></p>
            <div class="header-profile-circle">
              <img src="<?php echo $profilePic; ?>" alt="Admin Profile Pic" class="header-profile-img">
              <!-- Popup Menu -->
              <div id="profile-popup" class="popup hidden">
                  <div class="popup-buttons">
                      <button onclick="location.href='/RWDD/admin&teacher/adminEditProfile.php'" class="edit-profile">Edit Profile</button>                
                      <button class="sign-out" onclick="location.href='/RWDD/General/home.php'">Sign Out</button>
                  </div>
              </div>
        </div>
      </div>
      
    </header>
    
    <br><br>

    <section>
    <div class="burg">
      <label class="burger" for="burger">
        <input type="checkbox" id="burger">
        <span style="background: #fcf6d2;"></span>
        <span style="background: #fcf6d2;"></span>
        <span style="background: #fcf6d2;"></span>
      </label>
    </div>
    <div class="sidebar" id="sidebar">
    <ul class="menu">
    <li><a href="/RWDD/admin&teacher/adminPage.php" class="burg-home">Home</a></li>
        <li class="mobile-category">
            <a href="#" class="category-link">Category</a>
            <ul class="cat-dropdown">
                <li><a href="#">Arts and Humanities</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/01art.php'">Arts</a></li>
                    <li><a onclick="location.href='/RWDD/Category/02history.php'">History</a></li>
                    <li><a onclick="location.href='/RWDD/Category/03geo.php'">Geography</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Business and Commerce</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/04accounting.php'">Accounting</a></li>
                    <li><a onclick="location.href='/RWDD/Category/05finance.php'">Finance</a></li>
                    <li><a onclick="location.href='/RWDD/Category/06econ.php'">Economics</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Language</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/07eng.php'">English Language</a></li>
                    <li><a onclick="location.href='/RWDD/Category/08malay.php'">Malay Language / Bahasa Melayu</a></li>
                    <li><a onclick="location.href='/RWDD/Category/09chinese.php'">Chinese Language</a></li>
                    <li><a onclick="location.href='/RWDD/Category/10foreign.php'">Foreign Language</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Science, Technology, Engineering & Mathematics (STEM)</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/11bio.php'">Biology</a></li>
                    <li><a onclick="location.href='/RWDD/Category/12chem.php'">Chemistry</a></li>
                    <li><a onclick="location.href='/RWDD/Category/13comsci.php'">Computer Science</a></li>
                    <li><a onclick="location.href='/RWDD/Category/14science.php'">Science</a></li>
                    <li><a onclick="location.href='/RWDD/Category/15math.php'">Mathematics</a></li>
                    <li><a onclick="location.href='/RWDD/Category/16phy.php'">Physics</a></li>
                </ul>
            </ul>
        </li>
        <br>
        <hr class="nav-underline">
        <li><a href="/RWDD/admin&teacher/adminApproval.php" class="burg-edit">Approval</a></li>
        <li><a href="/RWDD/admin&teacher/adminViewAccount.php" class="burg-edit">View All Accounts</a></li>
        <hr class="nav-underline">
        <li><a href="/RWDD/admin&teacher/adminEditProfile.php" class="burg-edit">Edit Profile</a></li>
        <li><a href="/RWDD/General/home.php" class="burg-signout">Sign Out</a></li>
    </ul>
</div>
</section>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const burger = document.querySelector(".burger input");
    const sidebar = document.querySelector(".sidebar");
    const overlay = document.createElement("div");
    overlay.classList.add("overlay");
    document.body.appendChild(overlay);

    // Sidebar toggle
    burger.addEventListener("change", function () {
        sidebar.classList.toggle("active");
        overlay.classList.toggle("active");
    });

    // Close sidebar when clicking outside
    overlay.addEventListener("click", function () {
        sidebar.classList.remove("active");
        overlay.classList.remove("active");
        burger.checked = false;
    });

    // Dropdown toggle functionality
    const categories = document.querySelectorAll(".mobile-category");

    categories.forEach(category => {
        category.addEventListener("click", function () {
            this.classList.toggle("open");
        });
    });

    // Sub-category toggle functionality
    const subCategories = document.querySelectorAll(".cat-dropdown");

    subCategories.forEach(subCategory => {
        subCategory.addEventListener("click", function (event) {
            event.preventDefault(); // Prevent default link behavior
            this.parentElement.classList.toggle("open");
        });
    });
});
</script>

    <!-- below is desktop size -->

    <ul class="breadcrumb">
        <li><a href="adminPage.php">Home</a></li>
        <li><a href="adminViewAccount.php">All Accounts</a></li>
        <li>Account Details</li>
    </ul>
    <br><br>
    
    <!-- account details (copied from edit profile then modified abit) -->
    <h2 style="margin-left: 40px;">View Account Details</h2> 
    <p style="margin-left: 40px; margin-top: 15px;margin-bottom: 15px;">
    You are currently viewing ID : <?php echo htmlspecialchars($userID); ?> </p>

    <center>
        <div class="profile-container">
            <!-- Profile Picture Section -->
            <div class="profile-picture">
              <div class="picture-wrapper">
                 
                <img src="<?php echo $profilePicture; ?>" alt="Profile Pic" class="edit-profile-img">
              </div>
            </div>
        
            <!-- Form Section -->
            <form class="profile-form">
            <!-- Username Field -->
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" value="<?php echo htmlspecialchars($username); ?>" readonly>
                </div>

                <!-- Email Field -->
                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" value="<?php echo htmlspecialchars($email); ?>" readonly>
                </div>

                <?php if ($role == 'Teacher'): ?>
                <!-- Subject Taught Field -->
                <div class="input-group">
                    <label for="subjectTaught">Subject(s) Taught</label>
                    <input type="text" id="subjectTaught" value="<?php echo htmlspecialchars($subjectTaught); ?>" readonly>
                </div>
                <?php elseif ($role == 'Student'): ?>
                <!-- Grade Field -->
                <div class="input-group">
                    <label for="grade">Grade</label>
                    <input type="text" id="grade" value="<?php echo htmlspecialchars($grade); ?>" readonly>
                </div>
                <?php endif; ?>
        
            </form>

          </div>
    </center><br><br>

    <footer>
        <div class="footer-logo">
            <div class="logo-circle footer-logo-circle">
                <img src="/RWDD/Image/Tree Icon.png" alt="MindBloom Logo" class="logo footer-logo-img">
            </div>
            <span class="brand-name-footer">MindBloom</span>
        </div>
        <div class="footer-links">
            <div class="link-column">
                <h3>About Us</h3>
                <ul>
                    <li><a href="/RWDD/General/about.php">About MindBloom</a></li>
                    <li><a href="/RWDD/General/qna.php">Q&A</a></li>
                    <li><a href="/RWDD/General/contact.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="link-column">
                <h3>Resources</h3>
                <ul>
                    <li><a href="/RWDD/General/signup.php">Sign Up</a></li>
                    <li><a href="/RWDD/General/terms.php">Terms</a></li>
                    <li><a href="/RWDD/General/privacy.php">Privacy & Policy</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-social">
            <h2>Follow Us :</h2>
            <ul class="wrapper">
                <li class="icon facebook">
                  <span class="tooltip">Facebook</span>
                  <svg
                    viewBox="0 0 320 512"
                    height="1.2em"
                    fill="currentColor"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"
                    ></path>
                  </svg>
                </li>
              <li class="icon twitter">
                <span class="tooltip">Twitter</span>
                <svg
                  height="1.8em"
                  fill="currentColor"
                  viewBox="0 0 48 48"
                  xmlns="http://www.w3.org/2000/svg"
                  class="twitter"
                >
                  <path
                    d="M42,12.429c-1.323,0.586-2.746,0.977-4.247,1.162c1.526-0.906,2.7-2.351,3.251-4.058c-1.428,0.837-3.01,1.452-4.693,1.776C34.967,9.884,33.05,9,30.926,9c-4.08,0-7.387,3.278-7.387,7.32c0,0.572,0.067,1.129,0.193,1.67c-6.138-0.308-11.582-3.226-15.224-7.654c-0.64,1.082-1,2.349-1,3.686c0,2.541,1.301,4.778,3.285,6.096c-1.211-0.037-2.351-0.374-3.349-0.914c0,0.022,0,0.055,0,0.086c0,3.551,2.547,6.508,5.923,7.181c-0.617,0.169-1.269,0.263-1.941,0.263c-0.477,0-0.942-0.054-1.392-0.135c0.94,2.902,3.667,5.023,6.898,5.086c-2.528,1.96-5.712,3.134-9.174,3.134c-0.598,0-1.183-0.034-1.761-0.104C9.268,36.786,13.152,38,17.321,38c13.585,0,21.017-11.156,21.017-20.834c0-0.317-0.01-0.633-0.025-0.945C39.763,15.197,41.013,13.905,42,12.429"
                  ></path>
                </svg>
              </li>
              <li class="icon instagram">
                <span class="tooltip">Instagram</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="1.2em"
                  fill="currentColor"
                  class="bi bi-instagram"
                  viewBox="0 0 16 16"
                >
                  <path
                    d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"
                  ></path>
                </svg>
              </li>
            </ul>
        </div>
    </footer>
      
  
      <script>
                  document.querySelectorAll('.icon').forEach(icon => {
              icon.addEventListener('click', () => {
                  const url = {
                      facebook: 'https://www.facebook.com',
                      twitter: 'https://www.twitter.com',
                      instagram: 'https://www.instagram.com',
                  }[icon.classList[1]]; // Matches the second class name
  
                  if (url) {
                      window.open(url, '_blank'); // Opens the link in a new tab
                  }
              });
          });
      </script>

      <script src="/RWDD/General/popup.js"></script>
  
  </body>
  </html>
  
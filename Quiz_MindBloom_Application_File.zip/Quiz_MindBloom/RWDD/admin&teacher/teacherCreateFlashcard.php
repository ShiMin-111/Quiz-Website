<?php
// Start the session
session_start();

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');  //absolute path (you must enter specific path)

// Check if the user is logged in and has the role of 'Teacher'
if (!isset($_SESSION['userID']) || $_SESSION['role'] != 'Teacher') {
    header("Location: login.php");
    exit();
}

// Retrieve the teacher's profile data
$userID = $_SESSION['userID'];
$stmt = $dbConn->prepare("SELECT username, profilePicture FROM Users WHERE userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$stmt->bind_result($username, $profilePicture);
$stmt->fetch();
$stmt->close();

// Check if the profile picture is empty or NULL
if (!empty($profilePicture)) {
  // Convert BLOB to base64 format
  $profilePic = 'data:image/jpeg;base64,' . base64_encode($profilePicture);
} else {
  $profilePic = "/RWDD/Image/teacher.png"; // Default avatar
}

// Initialize $flashcardCategory to avoid "undefined variable" error
$flashcardCategory = null; 

// Handle form submission to save flashcard data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lessonName = $_POST['flashcard-name'];
    $flashcardCategory = $_POST['flashcard-category'];
    $createdBy = $_SESSION['userID'];
    $createdDate = date('Y-m-d');
  

    // Check if the file is uploaded
    if (isset($_FILES['banner-upload-input']) && $_FILES['banner-upload-input']['error'] == UPLOAD_ERR_OK) {
      $banner = file_get_contents($_FILES['banner-upload-input']['tmp_name']);
    } else {
        $banner = null; // Handle the case where no file is uploaded
    }

    // Insert flashcard data into the database
    $stmt = $dbConn->prepare("INSERT INTO lesson (userID, subjectID, lessonName, banner, createdDate) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $createdBy, $flashcardCategory, $lessonName, $banner, $createdDate);
    $stmt->execute();
    $lessonID = $stmt->insert_id;
    $stmt->close();

    // Redirect to add flashcard details page
    header("Location: teacherAddFlashcard.php?lessonID=$lessonID&lessonName=" . urlencode($lessonName));
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MindBloom</title>
    <link rel="stylesheet" href="/RWDD/admin&teacher/home.css"> 
    <link rel="stylesheet" href="/RWDD/admin&teacher/teacher.css"> 
    <link rel="stylesheet" href="/RWDD/admin&teacher/admin.css">
    <link rel="stylesheet" href="/RWDD/Student/burger.css"> 
</head>
<body>
  <header>
    <div class="header-logo">
        <div class="header-logo-circle">
            <img src="/RWDD/Image/Tree Icon.png" alt="MindBloom Logo" class="header-logo-img">
        </div>
        <span class="brand-name-header">MindBloom</span>
    </div>
    
    <div class="welcome">
      <p>Welcome back, <span><?php echo htmlspecialchars($_SESSION['username']); ?></span></p>
      <div class="header-profile-circle">
        <img src="<?php echo $profilePic; ?>" alt="Teacher Profile Pic" class="header-profile-img">
         <!-- Popup Menu -->
         <div id="profile-popup" class="popup hidden">
                <div class="popup-buttons">
                    <button onclick="location.href='/RWDD/admin&teacher/teacherEditProfile.php'" class="edit-profile">Edit Profile</button>                
                    <button class="sign-out" onclick="location.href='/RWDD/General/home.php'">Sign Out</button>
                </div>
          </div>
      </div>
    </div>

</header>
    <br><br>

    <section>
    <div class="burg">
      <label class="burger" for="burger">
        <input type="checkbox" id="burger">
        <span style="background: #fcf6d2;"></span>
        <span style="background: #fcf6d2;"></span>
        <span style="background: #fcf6d2;"></span>
      </label>
    </div>
    <div class="sidebar" id="sidebar">
    <ul class="menu">
    <li><a href="/RWDD/admin&teacher/teacherPage.php" class="burg-home">Home</a></li>
        <li class="mobile-category">
            <a href="#" class="category-link">Category</a>
            <ul class="cat-dropdown">
                <li><a href="#">Arts and Humanities</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/01art.php'">Arts</a></li>
                    <li><a onclick="location.href='/RWDD/Category/02history.php'">History</a></li>
                    <li><a onclick="location.href='/RWDD/Category/03geo.php'">Geography</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Business and Commerce</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/04accounting.php'">Accounting</a></li>
                    <li><a onclick="location.href='/RWDD/Category/05finance.php'">Finance</a></li>
                    <li><a onclick="location.href='/RWDD/Category/06econ.php'">Economics</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Language</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/07eng.php'">English Language</a></li>
                    <li><a onclick="location.href='/RWDD/Category/08malay.php'">Malay Language / Bahasa Melayu</a></li>
                    <li><a onclick="location.href='/RWDD/Category/09chinese.php'">Chinese Language</a></li>
                    <li><a onclick="location.href='/RWDD/Category/10foreign.php'">Foreign Language</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Science, Technology, Engineering & Mathematics (STEM)</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/11bio.php'">Biology</a></li>
                    <li><a onclick="location.href='/RWDD/Category/12chem.php'">Chemistry</a></li>
                    <li><a onclick="location.href='/RWDD/Category/13comsci.php'">Computer Science</a></li>
                    <li><a onclick="location.href='/RWDD/Category/14science.php'">Science</a></li>
                    <li><a onclick="location.href='/RWDD/Category/15math.php'">Mathematics</a></li>
                    <li><a onclick="location.href='/RWDD/Category/16phy.php'">Physics</a></li>
                </ul>
            </ul>
        </li>
        <br>
        <hr class="nav-underline">
        <li><a href="/RWDD/admin&teacher/teacherCreateQuiz.php" class="burg-edit">Create Quiz</a></li>
        <li><a href="/RWDD/admin&teacher/teacherCreateFlashcard.php" class="burg-edit">Create Flashcard</a></li>
        <hr class="nav-underline">
        <li><a href="/RWDD/admin&teacher/teacherEditProfile.php" class="burg-edit">Edit Profile</a></li>
        <li><a href="/RWDD/General/home.php" class="burg-signout">Sign Out</a></li>
    </ul>
</div>
</section>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const burger = document.querySelector(".burger input");
    const sidebar = document.querySelector(".sidebar");
    const overlay = document.createElement("div");
    overlay.classList.add("overlay");
    document.body.appendChild(overlay);

    // Sidebar toggle
    burger.addEventListener("change", function () {
        sidebar.classList.toggle("active");
        overlay.classList.toggle("active");
    });

    // Close sidebar when clicking outside
    overlay.addEventListener("click", function () {
        sidebar.classList.remove("active");
        overlay.classList.remove("active");
        burger.checked = false;
    });

    // Dropdown toggle functionality
    const categories = document.querySelectorAll(".mobile-category");

    categories.forEach(category => {
        category.addEventListener("click", function () {
            this.classList.toggle("open");
        });
    });

    // Sub-category toggle functionality
    const subCategories = document.querySelectorAll(".cat-dropdown");

    subCategories.forEach(subCategory => {
        subCategory.addEventListener("click", function (event) {
            event.preventDefault(); // Prevent default link behavior
            this.parentElement.classList.toggle("open");
        });
    });
});
</script>

    <!-- below is desktop size -->
    <ul class="breadcrumb">
      <li><a href="teacherPage.php">Home</a></li>
      <li>Create Flashcard</li>
    </ul>
    <br>
        
    <!-- copied from CREATE QUIZ -->
      <div class="flashcard-container">
        <div class="flashcard-header">
          <h2 style="background-color: rgba(138, 83, 41, 0.451);">Create Flashcard</h2>
        </div>
       <label for="flashcard-banner">Flashcard Banner</label>
          <div class="banner-upload">         
            <label for="banner-upload-input" class="upload-btn" id="upload-label">Upload</label>
            <div class="banner-preview-container">
              
        <form class="flashcard-form" method="POST" action="teacherCreateFlashcard.php" enctype="multipart/form-data">
        <!-- Flashcard Banner -->
        <div class="flashcard-banner">
         <img id="banner-preview" src="#" alt="Flashcard Banner Preview" style="display: none;">
            </div>
            <input type="file" id="banner-upload-input" name="banner-upload-input" accept="image/*" onchange="previewImage(event)" style="display: none;"> 
          </div>
        </div>

        <script>
          function previewImage(event) {
            var reader = new FileReader();
            var preview = document.getElementById('banner-preview');
            
            reader.onload = function() {
              preview.src = reader.result;
              preview.style.display = 'block';
              
              // Hide the upload button
              var uploadLabel = document.getElementById('upload-label');
              uploadLabel.style.display = 'none';
            };
            
            reader.readAsDataURL(event.target.files[0]);
          }
        </script>
      
        <!-- Flashcard Details -->
        <div class="flashcard-details">
          <label for="flashcard-name">Flashcard Name</label>
          <input type="text" id="flashcard-name" name="flashcard-name" placeholder="Enter Flashcard Name" required />
      
          <label for="flashcard-category">Flashcard Category</label>
          <select id="flashcard-category" name="flashcard-category" required>
            <option value="1" <?php echo $flashcardCategory == 1 ? 'selected' : ''; ?>>Arts & Humanities - Arts</option>
            <option value="2" <?php echo $flashcardCategory == 2 ? 'selected' : ''; ?>>Arts & Humanities - History</option>
            <option value="3" <?php echo $flashcardCategory == 3 ? 'selected' : ''; ?>>Arts & Humanities - Geography</option>
            <option value="4" <?php echo $flashcardCategory == 4 ? 'selected' : ''; ?>>Business & Commerce - Accounting</option>
            <option value="5" <?php echo $flashcardCategory == 5 ? 'selected' : ''; ?>>Business & Commerce - Finance</option>
            <option value="6" <?php echo $flashcardCategory == 6 ? 'selected' : ''; ?>>Business & Commerce - Economics</option>
            <option value="7" <?php echo $flashcardCategory == 7 ? 'selected' : ''; ?>>Language - English Language</option>
            <option value="8" <?php echo $flashcardCategory == 8 ? 'selected' : ''; ?>>Language - Malay Language / Bahasa Melayu</option>
            <option value="9" <?php echo $flashcardCategory == 9 ? 'selected' : ''; ?>>Language - Chinese Language</option>
            <option value="10" <?php echo $flashcardCategory == 10 ? 'selected' : ''; ?>>Language - Foreign Language</option>
            <option value="11" <?php echo $flashcardCategory == 11 ? 'selected' : ''; ?>>STEM - Biology</option>
            <option value="12" <?php echo $flashcardCategory == 12 ? 'selected' : ''; ?>>STEM - Chemistry</option>
            <option value="13" <?php echo $flashcardCategory == 13 ? 'selected' : ''; ?>>STEM - Computer Science</option>
            <option value="14" <?php echo $flashcardCategory == 14 ? 'selected' : ''; ?>>STEM - Science</option>
            <option value="15" <?php echo $flashcardCategory == 15 ? 'selected' : ''; ?>>STEM - Mathematics</option>
            <option value="16" <?php echo $flashcardCategory == 16 ? 'selected' : ''; ?>>STEM - Physics</option>
          </select>
        </div>
        
        <hr><br>
        <!-- Flashcards Section -->
        <div class="flashcard-questions">
          <div class="flashcard-qty">
            <h3>0 Flashcard(s)</h3>
            <button type="submit" name="add-flashcard" class="add-question">+ Add Flashcard</button>
          </div>
        </div>
      
      </form>
        
      </div>
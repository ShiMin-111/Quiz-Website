<?php
// Start the session
session_start();

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');  //absolute path (you must enter specific path)

// Check if the user is logged in and has the role of 'Teacher'
if (!isset($_SESSION['userID']) || $_SESSION['role'] != 'Teacher') {
    header("Location: login.php");
    exit();
}

// Retrieve the quiz ID from the URL
$quizID = $_GET['quizID'];

// Retrieve the quiz details
$quizStmt = $dbConn->prepare("SELECT quizTitle, createdDate, duration, banner FROM Quiz WHERE quizID = ?");
$quizStmt->bind_param("i", $quizID);
$quizStmt->execute();
$quizStmt->bind_result($quizTitle, $createdDate, $duration, $getbanner);
$quizStmt->fetch();
$quizStmt->close();

if (!empty($getbanner)) {
    // Convert BLOB to base64 format
    $banner = 'data:image/jpeg;base64,' . base64_encode($getbanner);
    } else {
    $banner = "/RWDD/Image/defaultquizbanners.jpg"; // Default avatar
    }

// Retrieve the questions for the quiz
$questions = [];
$questionStmt = $dbConn->prepare("SELECT questionID, questionText FROM Question WHERE quizID = ?");
$questionStmt->bind_param("i", $quizID);
$questionStmt->execute();
$questionStmt->bind_result($questionID, $questionText);
while ($questionStmt->fetch()) {
    $questions[] = ['questionID' => $questionID, 'questionText' => $questionText];
}
$questionStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MindBloom - View Quiz</title>
    <link rel="stylesheet" href="home.css"> 
    <link rel="stylesheet" href="teacher.css"> 
</head>
<body>
    <header>
        <div class="header-logo">
            <div class="header-logo-circle">
                <img src="/RWDD/Image/Tree Icon.png" alt="MindBloom Logo" class="header-logo-img">
            </div>
           </span>
        </div>
        
        <div class="welcome">
          <p>Welcome back, <span><?php echo htmlspecialchars($_SESSION['username']); ?></span></p>
          <div class="header-profile-circle">
            <img src="<?php echo $profilePic; ?>" alt="Teacher Profile Pic" class="header-profile-img">
             <!-- Popup Menu -->
            <div id="profile-popup" class="popup hidden">
                <div class="popup-buttons">
                    <button onclick="location.href='/RWDD/admin&teacher/teacherEditProfile.php'" class="edit-profile">Edit Profile</button>                
                    <button class="sign-out" onclick="location.href='/RWDD/General/home.php'">Sign Out</button>
                </div>
            </div>
        </div>
      </div>
    </header>
    <br><br>

    <ul class="breadcrumb">
        <li><a href="teacherPage.php">Home</a></li>
        <li><a href="teacherCreation.php">Your Creations</a></li>
        <li>View Quiz</li>
    </ul>

    <h2 style="margin-left:5%;padding: 2%;">Quiz Details</h2> 

    <section class="quiz-details">
        <div class="image-placeholder" style="margin-top:-3%">    <!-- The style can change, i just put it randomly -->
            <img src="<?php echo $banner; ?>" alt="Banner Pic" class="image-placeholder">
        </div>
        <h3><?php echo htmlspecialchars($quizTitle); ?></h3>        
        <p>Created Date: <?php echo htmlspecialchars($createdDate); ?></p>
        <p>Duration: <?php echo htmlspecialchars($duration); ?></p>
    </section>

    <section class="quiz-questions">
        <h3>Questions</h3>
        <div class="questions-list">
            <?php foreach ($questions as $question): ?>
                <div class="question-card">
                    <p><?php echo htmlspecialchars($question['questionText']); ?></p>
                    <div class="action-buttons">
                        <a href="deleteQuestion.php?questionID=<?php echo $question['questionID']; ?>" title="Delete">🗑️</a> 
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <a href="teacherAddQues.php?quizID=<?php echo $quizID; ?>&quizName=<?php echo urlencode($quizTitle); ?>" class="add-question">+ Add Question</a>
    </section>
</body>
</html>
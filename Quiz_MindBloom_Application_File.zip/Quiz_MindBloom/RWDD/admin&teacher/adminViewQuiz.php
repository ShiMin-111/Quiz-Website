<?php
// Start the session
session_start();

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');  //absolute path (you must enter specific path)

// Check if the user is logged in and has the role of 'Admin'
if (!isset($_SESSION['userID']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Retrieve the quiz ID from the URL
$quizID = $_GET['quizID'];

// Retrieve the quiz details including the category
$quizStmt = $dbConn->prepare("
    SELECT q.quizTitle, q.createdDate, q.duration, c.categoryName, u.username 
    FROM Quiz q
    JOIN Subject s ON q.subjectID = s.subjectID
    JOIN Category c ON s.categoryID = c.categoryID
    JOIN Users u ON q.createdBy = u.userID
    WHERE q.quizID = ?
");
$quizStmt->bind_param("i", $quizID);
$quizStmt->execute();
$quizStmt->bind_result($quizTitle, $createdDate, $duration, $categoryName, $teacherName);
$quizStmt->fetch();
$quizStmt->close();

// Retrieve the questions for the quiz
$questions = [];
$questionStmt = $dbConn->prepare("SELECT questionID, questionText FROM Question WHERE quizID = ?");
$questionStmt->bind_param("i", $quizID);
$questionStmt->execute();
$questionStmt->bind_result($questionID, $questionText);
while ($questionStmt->fetch()) {
    $questions[] = ['questionID' => $questionID, 'questionText' => $questionText];
}
$questionStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MindBloom - View Quiz</title>
    <link rel="stylesheet" href="/RWDD/admin&teacher/home.css"> 
    <link rel="stylesheet" href="admin.css"> 
    <link rel="stylesheet" href="/RWDD/Student/burger.css">
    <link rel="stylesheet" href="/RWDD/admin&teacher/teacher.css">
</head>
<body>
    <header>
        <div class="header-logo">
            <div class="header-logo-circle">
                <img src="/RWDD/Image/Tree Icon.png" alt="MindBloom Logo" class="header-logo-img">
            </div>
            <span class="brand-name-header">MindBloom</span>
        </div>
        
        <div class="welcome">
            <p>Welcome back, <span><?php echo htmlspecialchars($_SESSION['username']); ?></span></p>
            <div class="header-profile-circle">
                <img src="<?php echo $profilePic; ?>" alt="Admin Profile Pic" class="header-profile-img">
                <div id="profile-popup" class="popup hidden">
                    <div class="popup-buttons">
                        <button onclick="location.href='/RWDD/admin&teacher/adminEditProfile.php'">Edit Profile</button>
                        <button onclick="location.href='/RWDD/General/home.php'">Logout</button>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <br><br>

    <br><br>

    <section>
    <div class="burg">
      <label class="burger" for="burger">
        <input type="checkbox" id="burger">
        <span style="background: #fcf6d2;"></span>
        <span style="background: #fcf6d2;"></span>
        <span style="background: #fcf6d2;"></span>
      </label>
    </div>
    <div class="sidebar" id="sidebar">
    <ul class="menu">
    <li><a href="/RWDD/admin&teacher/adminPage.php" class="burg-home">Home</a></li>
        <li class="mobile-category">
            <a href="#" class="category-link">Category</a>
            <ul class="cat-dropdown">
                <li><a href="#">Arts and Humanities</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a href="/RWDD/Category/01art.php">Arts</a></li>
                    <li><a href="/RWDD/Category/02history.php">History</a></li>
                    <li><a href="/RWDD/Category/03geo.php">Geography</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Business and Commerce</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a href="/RWDD/Category/04accounting.php">Accounting</a></li>
                    <li><a href="/RWDD/Category/05finance.php">Finance</a></li>
                    <li><a href="/RWDD/Category/06econ.php">Economics</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Language</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a href="/RWDD/Category/07eng.php">English Language</a></li>
                    <li><a href="/RWDD/Category/08malay.php">Malay Language / Bahasa Melayu</a></li>
                    <li><a href="/RWDD/Category/09chinese.php">Chinese Language</a></li>
                    <li><a href="/RWDD/Category/10foreign.php">Foreign Language</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Science, Technology, Engineering & Mathematics (STEM)</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a href="/RWDD/Category/11bio.php">Biology</a></li>
                    <li><a href="/RWDD/Category/12chem.php">Chemistry</a></li>
                    <li><a href="/RWDD/Category/13comsci.php">Computer Science</a></li>
                    <li><a href="/RWDD/Category/14science.php">Science</a></li>
                    <li><a href="/RWDD/Category/15math.php">Mathematics</a></li>
                    <li><a href="/RWDD/Category/16phy.php">Physics</a></li>
                </ul>
            </ul>
        </li>
        <br>
        <hr class="nav-underline">
        <li><a href="/RWDD/admin&teacher/adminEditProfile.php" class="burg-edit">Edit Profile</a></li>
        <li><a href="/RWDD/General/home.php" class="burg-signout">Sign Out</a></li>
    </ul>
</div>
</section>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const burger = document.querySelector(".burger input");
    const sidebar = document.querySelector(".sidebar");
    const overlay = document.createElement("div");
    overlay.classList.add("overlay");
    document.body.appendChild(overlay);

    // Sidebar toggle
    burger.addEventListener("change", function () {
        sidebar.classList.toggle("active");
        overlay.classList.toggle("active");
    });

    // Close sidebar when clicking outside
    overlay.addEventListener("click", function () {
        sidebar.classList.remove("active");
        overlay.classList.remove("active");
        burger.checked = false;
    });

    // Dropdown toggle functionality
    const categories = document.querySelectorAll(".mobile-category");

    categories.forEach(category => {
        category.addEventListener("click", function () {
            this.classList.toggle("open");
        });
    });

    // Sub-category toggle functionality
    const subCategories = document.querySelectorAll(".cat-dropdown > li > a");

    subCategories.forEach(subCategory => {
        subCategory.addEventListener("click", function (event) {
            event.preventDefault();
            this.parentElement.classList.toggle("open");
        });
    });
});
</script>

    <!-- below is desktop size -->

    <ul class="breadcrumb">
        <li><a href="adminPage.php">Home</a></li>
        <li><a href="adminViewAccount.php">View Accounts</a></li>
        <li>View Quiz</li>
    </ul>

    <h2 style="margin-left:5%;padding: 2%;">Quiz Details</h2> 

    <section class="quiz-details">
        <h3><?php echo htmlspecialchars($quizTitle); ?></h3>
        <p>Category: <?php echo htmlspecialchars($categoryName); ?></p>
        <p>Created By: <?php echo htmlspecialchars($teacherName); ?></p>
        <p>Created Date: <?php echo htmlspecialchars($createdDate); ?></p>
        <p>Duration: <?php echo htmlspecialchars($duration); ?></p>
        <div class="action-buttons">
            <a href="deleteQuiz.php?quizID=<?php echo $quizID; ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this quiz?');">Delete Quiz</a>
        </div>
    </section>

    <section class="quiz-questions">
        <h3>Questions</h3>
        <div class="questions-list">
            <?php foreach ($questions as $question): ?>
                <div class="question-card">
                    <p><?php echo htmlspecialchars($question['questionText']); ?></p>
                    <div class="action-buttons">
                        <a href="deleteQuestion.php?questionID=<?php echo $question['questionID']; ?>" title="Delete" onclick="return confirm('Are you sure you want to delete this question?');">🗑️</a> 
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</body>
</html>
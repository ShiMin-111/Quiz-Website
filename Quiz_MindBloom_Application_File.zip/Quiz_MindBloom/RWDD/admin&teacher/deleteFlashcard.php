<?php
// deleteLesson.php
session_start();
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');

// Check if the user is logged in and has the role of 'Admin' or 'Teacher'
if (!isset($_SESSION['userID']) || ($_SESSION['role'] != 'Admin' && $_SESSION['role'] != 'Teacher')) {
    header("Location: /RWDD/General/login.php");
    exit();
}

// Retrieve questionID from either GET or POST
$flashcardID = isset($_POST['flashcardID']) ? $_POST['flashcardID'] : (isset($_GET['flashcardID']) ? $_GET['flashcardID'] : null);

if (!$flashcardID) {
    echo "<script>alert('Flashcard ID is missing!'); window.history.back();</script>";
    exit();
}


// Retrieve flashcardID and quizName
$stmt = $dbConn->prepare("SELECT lessonID FROM flashcard WHERE flashcardID = ?");
$stmt->bind_param("i", $flashcardID);
$stmt->execute();
$stmt->bind_result($lessonID);
$stmt->fetch();
$stmt->close();

$stmt = $dbConn->prepare("SELECT lessonName FROM lesson WHERE lessonID = ?");
$stmt->bind_param("i", $lessonID);
$stmt->execute();
$stmt->bind_result($lessonName);
$stmt->fetch();
$stmt->close();

// // Retrieve the lesson details to check the creator
// $lessonStmt = $dbConn->prepare("SELECT userID FROM lesson WHERE lessonID = ?");
// $lessonStmt->bind_param("i", $lessonID);
// $lessonStmt->execute();
// $lessonStmt->bind_result($userID);
// $lessonStmt->fetch();
// $lessonStmt->close();


// Check remaining questions in quiz
$stmt = $dbConn->prepare("SELECT COUNT(*) FROM flashcard WHERE lessonID = ?");
$stmt->bind_param("i", $lessonID);
$stmt->execute();
$stmt->bind_result($flashcardCount);
$stmt->fetch();
$stmt->close();

if ($flashcardCount <=1 ) {
        echo "<script>
        alert('You must have at least one flashcard to complete the lesson!');
        window.history.back();
        </script>";
} else {
    // Delete flashcards related to the lesson
    $deleteFlashcardStmt = $dbConn->prepare("DELETE FROM flashcard WHERE flashcardID = ?");
    $deleteFlashcardStmt->bind_param("i", $flashcardID);
    $deleteFlashcardStmt->execute();
    $deleteFlashcardStmt->close();

    if ($_SESSION['role'] != 'Admin') {
        echo "<script>alert('Flashcard deleted successfully!'); 
            window.location.href='/RWDD/admin&teacher/teacherCreateFlashcard2.php?lessonID=$lessonID&lessonName=" . urlencode($lessonName) . "';
        </script>";
    }else {
        echo "<script>alert('Flashcard deleted successfully!'); 
        window.history.back();
        </script>";
    }
}
?>

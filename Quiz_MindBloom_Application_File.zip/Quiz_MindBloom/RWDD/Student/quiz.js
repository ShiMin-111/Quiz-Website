document.addEventListener('DOMContentLoaded', () => {
  // Hamburger menu functionality
  const burger = document.getElementById('burger');
  const sidebar = document.getElementById('sidebar');

  burger.addEventListener('change', () => {
      if (burger.checked) {
          sidebar.style.display = 'block'; // Ensure the sidebar is visible
          sidebar.style.left = '0'; // Show sidebar
      } else {
          sidebar.style.left = '-250px'; // Hide sidebar
          setTimeout(() => {
              sidebar.style.display = 'none'; // Hide it completely after animation
          }, 300); // Match the transition time in CSS
      }
  });
});

const questions = [
{
  question: "What is the capital of France?",
  options: ["Paris", "London", "Berlin", "Madrid"],
  correct: 0,
},
{
  question: "What is 2 + 2?",
  options: ["3", "4", "5", "6"],
  correct: 1,
},
{
  question: "Which programming language is used for web development?",
  options: ["Python", "C++", "JavaScript", "Ruby"],
  correct: 2,
},
{
  question: "What is the largest planet in our solar system?",
  options: ["Earth", "Mars", "Jupiter", "Saturn"],
  correct: 2,
},
{
  question: "Which ocean is the largest?",
  options: ["Atlantic", "Indian", "Arctic", "Pacific"],
  correct: 3,
}
];

let currentQuestionIndex = 0; // Track the current question
let timeLeft = 60; // Time for each question
let score = 0; // Initialize score
const timerElement = document.getElementById("timer");
const questionElement = document.getElementById("question");
const answersElement = document.getElementById("answers");

// Load the first question
function loadQuestion() {
const currentQuestion = questions[currentQuestionIndex];
questionElement.textContent = currentQuestion.question;

// Clear previous options
answersElement.innerHTML = "";

// Load new options
currentQuestion.options.forEach((option, index) => {
const button = document.createElement("button");
button.textContent = option;
button.onclick = () => checkAnswer(index);
button.style.padding = "10px";
button.style.marginBottom = "10px";
button.style.width = "100%";
answersElement.appendChild(button);
});
}

// Check the selected answer
function checkAnswer(selectedIndex) {
const currentQuestion = questions[currentQuestionIndex];
const buttons = answersElement.children; // Get all answer buttons

// Disable all buttons after an answer is selected
for (let button of buttons) {
  button.disabled = true;
}

// Highlight the correct and selected answers
if (selectedIndex === currentQuestion.correct) {
  score++;
  buttons[selectedIndex].style.backgroundColor = "green"; // Correct answer
} else {
  buttons[selectedIndex].style.backgroundColor = "red"; // Wrong answer
  buttons[currentQuestion.correct].style.backgroundColor = "green"; // Highlight correct answer
}
}


// Move to the next question
function nextQuestion() {
currentQuestionIndex++;
if (currentQuestionIndex < questions.length) {
  timeLeft = 60; // Reset the timer
  loadQuestion();
} else {
  clearInterval(countdown); // Stop the timer
  endQuiz(); // Show the summary popup
}
}


// Countdown timer
const countdown = setInterval(() => {
timeLeft -= 1;
timerElement.textContent = `Time left: ${timeLeft}s`;

if (timeLeft <= 0) {
nextQuestion(); // Automatically move to the next question
}
}, 1000);

// Quit the quiz
function quitQuiz() {
clearInterval(countdown);
alert("You have quit the quiz.");
window.location.href = "/Student/homepage/homepage.html";
}

// Start the quiz by loading the first question
loadQuestion();

let totalTimeSpent = 0;

function endQuiz() {
console.log("Quiz finished!");
clearInterval(countdown);

// Calculate total time spent
totalTimeSpent = (questions.length * 60 - timeLeft) / 60;

// Update the summary popup
document.getElementById("score").textContent = score;
document.getElementById("time-spent").textContent = totalTimeSpent.toFixed(2);

// Show the summary popup
document.getElementById("summary-popup").style.display = "block";
}


function restartQuiz() {
currentQuestionIndex = 0;
score = 0;
timeLeft = 60;

document.getElementById("summary-popup").style.display = "none";
loadQuestion();
countdown = setInterval(updateTimer, 1000);
}

function findNewQuiz() {
alert("Redirecting to homepage...");
window.location.href = "/Student/homepage/homepage.html";
// You can redirect to a new quiz or perform any other action here
}
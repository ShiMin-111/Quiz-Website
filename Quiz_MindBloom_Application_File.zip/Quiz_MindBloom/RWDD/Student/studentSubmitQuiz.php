<?php
// Start the session
session_start();

// Check if the user is logged in and has the role of 'Student'
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Student') {
    // Redirect to login page if not logged in or not a student
    header("Location: /RWDD/General/login.php");
    exit();
}

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');

// Get the student's answers from the form submission
$answers = $_POST['answers'];
$quizID = $_GET['quizID'];
$userID = $_SESSION['userID'];

// Initialize the score
$score = 0;

// Prepare the SQL statement to retrieve questions and their correct options
$sql = "
    SELECT q.questionID, q.questionType, o.optionID, o.isCorrect 
    FROM Question q 
    JOIN Options o ON q.questionID = o.questionID 
    WHERE q.quizID = ?
";
$stmt = $dbConn->prepare($sql);
if (!$stmt) {
    die("Error preparing statement: " . $dbConn->error);
}
$stmt->bind_param('i', $quizID);
if (!$stmt->execute()) {
    die("Error executing statement: " . $stmt->error);
}
$result = $stmt->get_result();

// Organize the correct answers
$correctAnswers = [];
while ($row = $result->fetch_assoc()) {
    if (!isset($correctAnswers[$row['questionID']])) {
        $correctAnswers[$row['questionID']] = [
            'questionType' => $row['questionType'],
            'correctOptions' => [],
            'allOptions' => []
        ];
    }
    if ($row['isCorrect']) {
        $correctAnswers[$row['questionID']]['correctOptions'][] = $row['optionID'];
    }
    $correctAnswers[$row['questionID']]['allOptions'][] = $row['optionID'];
}

// Calculate the score
foreach ($correctAnswers as $questionID => $questionData) {
    // Get the student's selected options for this question
    $selectedOptionIDs = isset($answers[$questionID]) ? (array)$answers[$questionID] : [];

    if ($questionData['questionType'] === 'Multiple') {
        // For multiple-choice questions, check if all correct options are selected and no incorrect options are selected
        $isFullyCorrect = true;

        // Check if all correct options are selected
        foreach ($questionData['correctOptions'] as $correctOptionID) {
            if (!in_array($correctOptionID, $selectedOptionIDs)) {
                $isFullyCorrect = false;
                break;
            }
        }

        // Check if no incorrect options are selected
        foreach ($selectedOptionIDs as $selectedOptionID) {
            if (!in_array($selectedOptionID, $questionData['correctOptions'])) {
                $isFullyCorrect = false;
                break;
            }
        }

        // Award 1 mark if fully correct
        if ($isFullyCorrect) {
            $score++;
        }
    } else {
        // For single-choice questions, check if the selected option is correct
        if (count($selectedOptionIDs) === 1 && in_array($selectedOptionIDs[0], $questionData['correctOptions'])) {
            $score++;
        }
    }
}

// Insert the submission into the database
$submissionDate = date('Y-m-d');
$insertStmt = $dbConn->prepare("INSERT INTO Submission (quizID, userID, score, submissionDate) VALUES (?, ?, ?, ?)");
if (!$insertStmt) {
    die("Error preparing insert statement: " . $dbConn->error);
}
$insertStmt->bind_param('iiis', $quizID, $userID, $score, $submissionDate);
if (!$insertStmt->execute()) {
    die("Error executing insert statement: " . $insertStmt->error);
}

// Return the score and time spent as JSON
$response = [
    'score' => $score,
    'timeSpent' => $_POST['timeSpent']
];
echo json_encode($response);
?>
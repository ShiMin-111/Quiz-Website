let currentIndex = 0;
let isFlipped = false;

function updateFlashcard() {
    const cardFront = document.querySelector('.flashcard-front');
    const cardBack = document.querySelector('.flashcard-back');
    cardFront.innerText = flashcards[currentIndex].topic;
    cardBack.innerText = flashcards[currentIndex].description;
    document.querySelector('.flashcard-header').innerText = `${currentIndex + 1} / ${flashcards.length}`;

    const endButton = document.querySelector('.end-button');
    if (currentIndex === flashcards.length - 1) {
        endButton.style.display = 'block';
    } else {
        endButton.style.display = 'none';
    }
}

function showNextFlashcard() {
    if (currentIndex < flashcards.length - 1) {
        currentIndex++;
        isFlipped = false;
        document.querySelector('.flashcard').classList.remove('is-flipped');
        updateFlashcard();
    }
}

function showPreviousFlashcard() {
    if (currentIndex > 0) {
        currentIndex--;
        isFlipped = false;
        document.querySelector('.flashcard').classList.remove('is-flipped');
        updateFlashcard();
    }
}

function flipCard() {
    const card = document.querySelector('.flashcard');
    isFlipped = !isFlipped;
    if (isFlipped) {
        card.classList.add('is-flipped');
    } else {
        card.classList.remove('is-flipped');
    }
}

function showSummaryPopup() {
    const popup = document.querySelector('.summary-popup');
    popup.style.display = 'block';
}

function hideSummaryPopup() {
    const popup = document.querySelector('.summary-popup');
    popup.style.display = 'none';
    currentIndex = 0;
    updateFlashcard();
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('.navigation-right').addEventListener('click', showNextFlashcard);
    document.querySelector('.navigation-left').addEventListener('click', showPreviousFlashcard);
    document.querySelector('.flashcard').addEventListener('click', flipCard);
    document.querySelector('.end-button').addEventListener('click', showSummaryPopup);
    document.querySelector('.view-again').addEventListener('click', hideSummaryPopup);
    updateFlashcard();
});
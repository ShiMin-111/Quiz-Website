<?php

// Database connection parameters
$localhost = 'localhost';
$user = 'root';
$pass = '';
$dbName = 'mindbloom';

// Create a connection
$dbConn = mysqli_connect($localhost, $user, $pass, $dbName);

// Check the connection
if (mysqli_connect_errno()) {
    die('<script>alert("Connection failed: Please check your SQL connection!");</script>');
}

// echo "<script>alert('Successfully connected to DB!');</script>";

?>

<?php
// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php'); // Absolute path

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the email from the form and sanitize it
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format.'); window.location.href='forgetPassword.php';</script>";
        exit();
    }

    // Check if the email exists in the database
    $stmt = $dbConn->prepare("SELECT userID FROM Users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Fetch user ID
        $stmt->bind_result($userID);
        $stmt->fetch();
        $stmt->close();

        // Generate a unique token
        $token = bin2hex(random_bytes(50));

        // Set token expiration time (1 hour from now)
        $expires = date("U") + 3600;

        // Insert the token into the database
        $stmt = $dbConn->prepare("INSERT INTO PasswordReset (userID, token, expires) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $userID, $token, $expires);
        $stmt->execute();
        $stmt->close();

        // Verify that token was saved
        $stmt = $dbConn->prepare("SELECT token FROM PasswordReset WHERE userID = ? ORDER BY expires DESC LIMIT 1");
        $stmt->bind_param("i", $userID);
        $stmt->execute();
        $stmt->bind_result($dbToken);
        $stmt->fetch();
        $stmt->close();

        if (!$dbToken) {
            echo "<script>alert('Error: Token was not saved. Please try again.'); window.location.href='forgetPassword.php';</script>";
            exit();
        }

        // Generate the password reset link
        $resetLink = "http://localhost/RWDD/General/resetPassword.php?token=" . urlencode($token);

        // Email content
        $subject = "Password Reset Request";
        $message = "
        <html>
        <head>
            <title>Password Reset Request</title>
        </head>
        <body>
            <p>Click the link below to reset your password:</p>
            <p><a href='$resetLink'>$resetLink</a></p>
            <p>This link will expire in 1 hour.</p>
        </body>
        </html>";

        // Email headers
        $headers = "From: mindbloom102024@gmail.com\r\n";
        $headers .= "Reply-To: mindbloom102024@gmail.com\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

        // Force PHP to use Gmail SMTP settings
        ini_set("SMTP", "smtp.gmail.com");
        ini_set("smtp_port", "587");
        ini_set("sendmail_from", "mindbloom102024@gmail.com");
        ini_set("sendmail_path", "\"C:\xampp\sendmail\sendmail.exe\" -t");

        // Send email
        if (mail($email, $subject, $message, $headers)) {
            echo "<script>alert('Password reset link has been sent to your email.'); window.location.href='login.php';</script>";
        } else {
            echo "<script>alert('Failed to send email. Please try again later.'); window.location.href='forgetPassword.php';</script>";
            error_log(print_r(error_get_last(), true)); // Log the error for debugging
        }
    } else {
        echo "<script>alert('No account found with that email.'); window.location.href='forgetPassword.php';</script>";
    }

    // Close the database connection
    $stmt->close();
    $dbConn->close();
}
?>

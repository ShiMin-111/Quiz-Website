<?php
// Start the session
session_start();

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');  //absolute path (you must enter specific path)

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to login page if not logged in
    header("Location: /RWDD/General/login.php");
    exit();
}

// Fetch the userID from the session
$userID = $_SESSION['userID'];

// Update the user's status to 'deleted'
$stmt = $dbConn->prepare("UPDATE Users SET approvalStatus = 'deleted' WHERE userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$stmt->close();

// Destroy the session and redirect to the login page
session_destroy();
header("Location: /RWDD/General/login.php");
exit();
?>
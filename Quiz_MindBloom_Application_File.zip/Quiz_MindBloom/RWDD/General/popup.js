// Profile popup functionality
const profileIcon = document.querySelector('.header-profile-circle');
const popup = document.getElementById('profile-popup');

if (profileIcon && popup) {
    profileIcon.addEventListener('click', () => {
        popup.classList.toggle('hidden');
    });

    // Close popup when clicking outside
    document.addEventListener('click', (event) => {
        if (!popup.contains(event.target) && !profileIcon.contains(event.target)) {
            popup.classList.add('hidden');
        }
    });
} else {
    console.error('Profile icon or popup element not found!');
}

const categoryPopup = document.getElementById('categoryPopup');

function toggleCategoryPopup() {
    categoryPopup.classList.toggle('active'); // Show or hide the main popup
}

function toggleSubcategories(id) {
    const subcategoryList = document.getElementById(id);
    if (subcategoryList) {
        subcategoryList.classList.toggle('active'); // Show or hide the subcategories
    }
}
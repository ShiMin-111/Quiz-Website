<?php
// Include database connection
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $newPassword = $_POST['new-password'];
    $confirmPassword = $_POST['confirm-new-password'];

    // Check if passwords match
    if ($newPassword !== $confirmPassword) {
        echo "<script>alert('Passwords do not match.'); window.location.href='resetPassword.php?token=" . htmlspecialchars($token) . "';</script>";
        exit();
    }

    // Hash the new password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Verify the token and get the user ID
    $stmt = $dbConn->prepare("SELECT userID FROM PasswordReset WHERE token = ? AND expires >= ?");
    $currentTime = date("U");
    $stmt->bind_param("si", $token, $currentTime);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($userID);
        $stmt->fetch();
        $stmt->close();

        // Update the user's password
        $stmt = $dbConn->prepare("UPDATE Users SET password = ? WHERE userID = ?");
        $stmt->bind_param("si", $hashedPassword, $userID);
        $stmt->execute();
        $stmt->close();

        // Delete the token after reset
        $stmt = $dbConn->prepare("DELETE FROM PasswordReset WHERE userID = ?");
        $stmt->bind_param("i", $userID);
        $stmt->execute();
        $stmt->close();

        echo "<script>alert('Your password has been reset successfully!'); window.location.href='login.php';</script>";
    } else {
        echo "<script>alert('Invalid or expired reset token.'); window.location.href='forgetPassword.php';</script>";
    }
    
    $dbConn->close();
}
?>
document.addEventListener('DOMContentLoaded', () => {
    
    // Functionality for social media icons
    document.querySelectorAll('.icon').forEach(icon => {
        icon.addEventListener('click', () => {
            const url = {
                facebook: 'https://www.facebook.com',
                twitter: 'https://www.twitter.com',
                instagram: 'https://www.instagram.com',
            }[icon.classList[1]]; // Matches the second class name

            if (url) {
                window.open(url, '_blank'); // Opens the link in a new tab
            }
        });
    });

    // Hamburger menu functionality
    const burger = document.getElementById('burger');
    const sidebar = document.getElementById('sidebar');

    burger.addEventListener('change', () => {
        if (burger.checked) {
            sidebar.style.display = 'block'; // Ensure the sidebar is visible
            sidebar.style.left = '0'; // Show sidebar
        } else {
            sidebar.style.left = '-250px'; // Hide sidebar
            setTimeout(() => {
                sidebar.style.display = 'none'; // Hide it completely after animation
            }, 300); // Match the transition time in CSS
        }
    });
});


<?php
$to_email = "thongyutung@gmail.com";
$subject = "Test Email from XAMPP";
$body = "Hi, this is a test email sent from XAMPP using Gmail.";
$headers = "From: mindbloom102024@gmail.com";

if (mail($to_email, $subject, $body, $headers)) {
    echo "Email successfully sent to $to_email...";
} else {
    echo "Email sending failed...";
}
?>
<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to login page if not logged in
    header("Location: /RWDD/General/login.php");
    exit();
}

// Include the database connection file
include($_SERVER['DOCUMENT_ROOT'] . '/RWDD/General/conn.php');

// Get the user's role from the session
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';

// Determine the home page link and profile picture based on the user's role
$homePage = '';
$editProfilePage = '';
$profilePic = '';
if ($role == 'Student') {
    $homePage = '/RWDD/Student/studentPage.php';
    $editProfilePage = '/RWDD/Student/studentEditProfile.php';
    $profilePic = '/RWDD/Image/student.png';
} elseif ($role == 'Teacher') {
    $homePage = '/RWDD/admin&teacher/teacherPage.php';
    $editProfilePage = '/RWDD/admin&teacher/teacherEditProfile.php';
    $profilePic = '/RWDD/Image/teacher.png';
} elseif ($role == 'Admin') {
    $homePage = '/RWDD/admin&teacher/adminPage.php';
    $editProfilePage = '/RWDD/admin&teacher/adminEditProfile.php';
    $profilePic = '/RWDD/Image/admin.png';
}

// Retrieve the user's profile picture from the database if available
$userID = $_SESSION['userID'];
$stmt = $dbConn->prepare("SELECT profilePicture FROM Users WHERE userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$stmt->bind_result($profilePicture);
$stmt->fetch();
$stmt->close();

// Check if the profile picture is empty or NULL
if (!empty($profilePicture)) {
    // Convert BLOB to base64 format
    $profilePic = 'data:image/jpeg;base64,' . base64_encode($profilePicture);
}

// Retrieve the lesson ID from the URL
$lessonID = $_GET['lessonID'];

// Retrieve the lesson details including the category, subject, and created date
$lessonStmt = $dbConn->prepare("
    SELECT l.lessonName, l.banner, c.categoryName, s.subjectName, u.username, l.userID, l.createdDate
    FROM Lesson l
    JOIN Subject s ON l.subjectID = s.subjectID
    JOIN Category c ON s.categoryID = c.categoryID
    JOIN Users u ON l.userID = u.userID
    WHERE l.lessonID = ?
");
$lessonStmt->bind_param("i", $lessonID);
$lessonStmt->execute();
$lessonStmt->bind_result($lessonName, $getbanner, $categoryName, $subjectName, $teacherName, $createdBy, $createdDate);
$lessonStmt->fetch();
$lessonStmt->close();

if (!empty($getbanner)) {
    // Convert BLOB to base64 format
    $banner = 'data:image/jpeg;base64,' . base64_encode($getbanner);
} else {
    $banner = "/RWDD/Image/defaultQuizBanner.jpg"; // Default avatar
}

// Retrieve the flashcards for the lesson
$flashcards = [];
$flashcardStmt = $dbConn->prepare("SELECT flashcardID, topic, description FROM flashcard WHERE lessonID = ?");
$flashcardStmt->bind_param("i", $lessonID);
$flashcardStmt->execute();
$flashcardStmt->bind_result($flashcardID, $topic, $description);
while ($flashcardStmt->fetch()) {
    $flashcards[] = ['flashcardID' => $flashcardID, 'topic' => $topic, 'description' => $description];
}
$flashcardStmt->close();

// Function to check if the user is the creator of the lesson
function isCreator($createdBy, $userID) {
    return $createdBy == $userID;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MindBloom - View Lesson</title>
    <link rel="stylesheet" href="/RWDD/admin&teacher/home.css">
    <link rel="stylesheet" href="/RWDD/admin&teacher/teacher.css">
    <link rel="stylesheet" href="/RWDD/Student/burger.css">
    <link rel="stylesheet" href="/RWDD/Student/flashcard.css">
    <link rel="stylesheet" href="/RWDD/admin&teacher/admin.css">
</head>
<body>
<header>
    <div class="header-logo">
        <div class="header-logo-circle">
            <img src="/RWDD/Image/Tree Icon.png" alt="MindBloom Logo" class="header-logo-img">
        </div>
        <span class="brand-name-header">MindBloom</span>
    </div>
    <div class="welcome">
        <p>Welcome back, <span><?php echo htmlspecialchars($_SESSION['username']); ?></span></p>
        <div class="header-profile-circle">
            <img src="<?php echo $profilePic; ?>" alt="Profile Pic" class="header-profile-img">
            <!-- Popup Menu -->
            <div id="profile-popup" class="popup hidden">
                <div class="popup-buttons">
                    <button onclick="location.href='<?php echo $editProfilePage; ?>'" class="edit-profile">Edit Profile</button>                
                    <button class="sign-out" onclick="location.href='/RWDD/General/home.php'">Sign Out</button>
                </div>
            </div>
        </div>
    </div>
</header>

<script>
// Profile popup functionality
const profileIcon = document.querySelector('.header-profile-circle');
const popup = document.getElementById('profile-popup');

if (profileIcon && popup) {
    profileIcon.addEventListener('click', () => {
        popup.classList.toggle('hidden');
    });

    // Close popup when clicking outside
    document.addEventListener('click', (event) => {
        if (!popup.contains(event.target) && !profileIcon.contains(event.target)) {
            popup.classList.add('hidden');
        }
    });
} else {
    console.error('Profile icon or popup element not found!');
}

const categoryPopup = document.getElementById('categoryPopup');

function toggleCategoryPopup() {
    categoryPopup.classList.toggle('active'); // Show or hide the main popup
}

function toggleSubcategories(id) {
    const subcategoryList = document.getElementById(id);
    if (subcategoryList) {
        subcategoryList.classList.toggle('active'); // Show or hide the subcategories
    }
}
</script>
    
    <br><br>

    <section>
    <div class="burg">
      <label class="burger" for="burger">
        <input type="checkbox" id="burger">
        <span style="background: #fcf6d2;"></span>
        <span style="background: #fcf6d2;"></span>
        <span style="background: #fcf6d2;"></span>
      </label>
    </div>
    <div class="sidebar" id="sidebar" style="width:250px">
    <ul class="menu">
    <li><a href="<?php echo $homePage; ?>">Home</a></li>
        <li class="mobile-category">
            <a href="#" class="category-link">Category</a>
            <ul class="cat-dropdown">
                <li><a href="#">Arts and Humanities</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/01art.php'">Arts</a></li>
                    <li><a onclick="location.href='/RWDD/Category/02history.php'">History</a></li>
                    <li><a onclick="location.href='/RWDD/Category/03geo.php'">Geography</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Business and Commerce</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/04accounting.php'">Accounting</a></li>
                    <li><a onclick="location.href='/RWDD/Category/05finance.php'">Finance</a></li>
                    <li><a onclick="location.href='/RWDD/Category/06econ.php'">Economics</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Language</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/07eng.php'">English Language</a></li>
                    <li><a onclick="location.href='/RWDD/Category/08malay.php'">Malay Language / Bahasa Melayu</a></li>
                    <li><a onclick="location.href='/RWDD/Category/09chinese.php'">Chinese Language</a></li>
                    <li><a onclick="location.href='/RWDD/Category/10foreign.php'">Foreign Language</a></li>
                </ul>
            </ul>
            <ul class="cat-dropdown">
                <li><a href="#">Science, Technology, Engineering & Mathematics (STEM)</a></li>
                <ul class="sub-cat-dropdown">
                    <li><a onclick="location.href='/RWDD/Category/11bio.php'">Biology</a></li>
                    <li><a onclick="location.href='/RWDD/Category/12chem.php'">Chemistry</a></li>
                    <li><a onclick="location.href='/RWDD/Category/13comsci.php'">Computer Science</a></li>
                    <li><a onclick="location.href='/RWDD/Category/14science.php'">Science</a></li>
                    <li><a onclick="location.href='/RWDD/Category/15math.php'">Mathematics</a></li>
                    <li><a onclick="location.href='/RWDD/Category/16phy.php'">Physics</a></li>
                </ul>
            </ul>
        </li>
        <br>
        <hr class="nav-underline">
        <?php if ($role == 'Teacher'): ?>
            <li><a href="/RWDD/admin&teacher/teacherCreateQuiz.php" class="burg-edit">Create Quiz</a></li>
            <li><a href="/RWDD/admin&teacher/teacherCreateFlashcard.php" class="burg-edit">Create Flashcard</a></li>
            <hr class="nav-underline">
        <?php elseif ($role == 'Admin'): ?>
            <li><a href="/RWDD/admin&teacher/adminApproval.php" class="burg-edit">Approval</a></li>
            <li><a href="/RWDD/admin&teacher/adminViewAccount.php" class="burg-edit">View All Accounts</a></li>
            <hr class="nav-underline">
        <?php endif; ?>
        
        <li><a href="<?php echo $editProfilePage; ?>" class="burg-edit">Edit Profile</a></li>
        <li><a href="/RWDD/General/home.php" class="burg-signout">Sign Out</a></li>
    </ul>
</div>
</section>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const burger = document.querySelector(".burger input");
    const sidebar = document.querySelector(".sidebar");
    const overlay = document.createElement("div");
    overlay.classList.add("overlay");
    document.body.appendChild(overlay);

    // Sidebar toggle
    burger.addEventListener("change", function () {
        sidebar.classList.toggle("active");
        overlay.classList.toggle("active");
    });

    // Close sidebar when clicking outside
    overlay.addEventListener("click", function () {
        sidebar.classList.remove("active");
        overlay.classList.remove("active");
        burger.checked = false;
    });

    // Dropdown toggle functionality
    const categories = document.querySelectorAll(".mobile-category");

    categories.forEach(category => {
        category.addEventListener("click", function () {
            this.classList.toggle("open");
        });
    });

    // Sub-category toggle functionality
    const subCategories = document.querySelectorAll(".cat-dropdown");

    subCategories.forEach(subCategory => {
        subCategory.addEventListener("click", function (event) {
            event.preventDefault(); // Prevent default link behavior
            this.parentElement.classList.toggle("open");
        });
    });
});
</script>

    <!-- below is desktop size -->

    <ul class="breadcrumb">
    <li><a href="<?php echo $homePage; ?>">Home</a></li>
    <?php if ($_SESSION['role'] == 'Admin'): ?>
        <li>View Lesson</li>
    <?php elseif ($_SESSION['role'] == 'Teacher'): ?>
        <li><a href="/RWDD/admin&teacher/teacherCreation.php">Your Creations</a></li>
        <li>View Lesson</li>
    <?php elseif ($_SESSION['role'] == 'Student'): ?>
        <li>View Lesson</li>
    <?php endif; ?>
</ul>
    <br><br>

<main>
    <section class="lesson-details">
        <h3><?php echo htmlspecialchars($lessonName); ?></h3>
        <p>Category: <?php echo htmlspecialchars($categoryName); ?></p>
        <p>Subject: <?php echo htmlspecialchars($subjectName); ?></p>
        <p>Created By: <?php echo htmlspecialchars($teacherName); ?></p>
        <p>Created Date: <?php echo htmlspecialchars($createdDate); ?></p>
        <div class="action-buttons">
            <?php if ($role == 'Admin'): ?>
                <a href="/RWDD/admin&teacher/deleteLesson.php?lessonID=<?php echo $lessonID; ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this lesson?');">Delete Lesson</a>
            <?php elseif ($role == 'Teacher' && isCreator($createdBy, $_SESSION['userID'])): ?>
                <a href="/RWDD/admin&teacher/teacherCreateFlashcard2.php?lessonID=<?php echo $lessonID; ?>&lessonName=<?php echo urlencode($lessonName); ?>" class="edit-button">Edit Lesson</a>
                <a href="/RWDD/admin&teacher/deleteLesson.php?lessonID=<?php echo $lessonID; ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this lesson?');">Delete Lesson</a>
            <?php endif; ?>
        </div>
    </section>

    <div class="flashcard-container">
        <div class="flashcard-header">1 / <?php echo count($flashcards); ?></div>
        <span class="exit-button">&times;</span>
        <div class="flashcard">
            <div class="flashcard-side flashcard-front">
                <!-- Question will appear here -->
            </div>
            <div class="flashcard-side flashcard-back">
                <!-- Answer will appear here -->
            </div>
        </div>
        <div class="navigation navigation-left">&#9664;</div>
        <div class="navigation navigation-right">&#9654;</div>
        <button class="end-button">End Flashcard</button>
    </div>

    <div class="summary-popup">
        <h2>Summary</h2>
        <hr class="nav-underline"><br>
        <p>You made it to the end!</p><br>
        <div class="summary-actions">
            <button class="view-again" onclick="restartFlashcard()">View it again</button>
            <?php if ($role == 'Student'): ?>
                <button class="find-new" onclick="location.href='/RWDD/Student/studentPage.php'">Find a new flashcard</button>
            <?php endif; ?>
        </div>
    </div>
</main>

<script>
    const flashcards = <?php echo json_encode($flashcards); ?>;
</script>
<script src="/RWDD/Student/flashcard.js"></script>
</body>
</html>